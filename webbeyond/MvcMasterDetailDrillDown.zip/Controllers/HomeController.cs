﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class HomeController : Controller
    {
        Repository _repository = new Repository();

        public ActionResult Index()
        {            
            return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ResultView(FormCollection collection)
        {
            DateTime start = DateTime.Parse(collection["StartDate"]);
            DateTime end = DateTime.Parse(collection["EndDate"]);

            var model = _repository.GetOrders(start, end);
            return View(model);
        }
        
        public ActionResult ResultDetailView(int id)
        {
            var model = _repository.GetOrderItems(id);
            return PartialView(model);
        }
    }
}
