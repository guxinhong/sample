﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MvcApplication1.Models
{
    public class Repository
    {
        private List<Order> _orders = new List<Order>()
            {
                new Order
                    {
                        OrderId = 1,
                        OrderDate = new DateTime(2013, 10, 1),
                        CustomerId = 100,
                        OrderItems = new []
                            {
                                new OrderItem {OrderId = 1, Seq = 1, ProductId = 101, Qty = 1},
                                new OrderItem {OrderId = 1, Seq = 2, ProductId = 201, Qty = 2},
                                new OrderItem {OrderId = 1, Seq = 3, ProductId = 301, Qty = 3},
                            }
                    },
                new Order
                    {
                        OrderId = 2,
                        OrderDate = new DateTime(2013, 10, 2),
                        CustomerId = 200,
                        OrderItems = new []
                            {
                                new OrderItem {OrderId = 2, Seq = 1, ProductId = 401, Qty = 4},
                                new OrderItem {OrderId = 2, Seq = 2, ProductId = 501, Qty = 5}                                
                            }
                    }
            };

        public IEnumerable<Order> GetOrders(DateTime startDate, DateTime endDate)
        {
            return _orders.Where(p => p.OrderDate >= startDate && p.OrderDate <= endDate)
                   .Select(o => new Order { OrderId = o.OrderId, 
                       OrderDate = o.OrderDate, 
                       CustomerId = o.CustomerId} );            
        }

        public IEnumerable<OrderItem> GetOrderItems(int orderId)
        {
            var ord = _orders.SingleOrDefault(p => p.OrderId == orderId);
            return (ord != null) ? ord.OrderItems : null;
        }
    }
}